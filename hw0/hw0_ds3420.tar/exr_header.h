//
//  exr_header.h
//  hw0
//
//  Created by lindashen on 9/18/16.
//  Copyright © 2016 lindashen. All rights reserved.
//

#ifndef exr_header_h
#define exr_header_h


#include <ImfRgbaFile.h>
#include <ImfStringAttribute.h>
#include <ImfMatrixAttribute.h>
#include <ImfArray.h>

#include <iostream>

using namespace std;
using namespace Imf;
using namespace Imath;

#endif /* exr_header_h */
